#/bin/sh
latex patterns-utf8.tex 
dvipdf patterns-utf8.dvi patterns-utf8.pdf