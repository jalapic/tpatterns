% maxPattern( events, Nt, min_alphas_Nabs, no_same_events, ci_strategy )
% ci_strategy: 1 - longest 2 - shortest 3 - most significant
