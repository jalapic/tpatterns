% mexCalcLH( event, Nt, pat, from_end, start_index )   
% ci_strategy: 1 - longest 2 - shortest 3 - most significant
