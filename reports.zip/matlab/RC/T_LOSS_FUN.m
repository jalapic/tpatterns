function p = T_LOSS_FUN( x, N )
p = exp( - 8 * (x) / N );
if ( x == N )
    p = 0;
end
end

