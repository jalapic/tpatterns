
%% Pr


sigma = 5;
filter_window = 1;
pattern_window = 500;
dist_win = 9

tic
CIs = [30 34; 10 14; 3 6; 5 7; 3 6];
levels = [ 2 0.00005 4; 4 0.0005 3 ];
[events, Nt] = T_LOAD_FILE('../real_data/grooming_hamsters/eversmanni116.txt'); %'../real_data/grooming_hamsters/auratus1.txt');
%[events, Nt, ts] = T_GENERATE_PATTERN('abcdef', 'xyz', CIs, 8, 3000, 0.03, 0.03);
%ss = mexPattern(events, Nt, levels', 0, 1);
size(events(1).indexes, 2)
AB = zeros( size(events(1).indexes, 2),  size(events(2).indexes, 2));
for i = 1 :  size(events(1).indexes, 2)
    for j = 1 : size( events(2).indexes, 2)
        AB(i,j) = events(2).indexes(j) - events(1).indexes(i);
        if AB(i,j) > pattern_window
            AB(i,j) = 0;
        end
    end
end
AB;

cla
hold on
H = zeros(1, max(max(AB)) );
X = 0:0.01:max(max(AB));
N = size( X, 2);
yy = zeros(1, N);
maximums = [];

for i = 1 : size( events(1).indexes, 2)
    d = (AB(i,:)>0).*AB(i,:);
    plot(  d, i .* ones(1,size( d)), '*', 'MarkerSize', 2, 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'b' ) ;
    for j = 1 : size(d,2) 
        if (d(j) > 0)
            H( d(j) ) = H( d(j) ) + 1;
        end
        if ( d(j) ~= 0 )
            yy = yy + 1/(sigma*sqrt(2*pi)) * exp( - ( ( X - d(j) ).^2 )/(2*sigma*sigma) );
            %yy = yy - abs( X - d(j) );
        end
    end
end

%find minimums in yy
for i = 11:size(yy,2)-11
    if ( ( yy(i-10) < yy(i) ) && ( yy(i-5) < yy(i) ) && ( yy(i+10) < yy(i) ) && ( yy(i+5) < yy(i) ) )
        maximums( size(maximums, 2) + 1 ) = int16(i/100);
        plot( i/100, 0, 's', 'MarkerSize', 5, 'MarkerFaceColor', 'y', 'MarkerEdgeColor', 'r');
    end
end
maximums = unique(maximums)
%get distributions
for i = 1 : size(maximums, 2)
    mu=maximums(i);
    line = -dist_win:0.01:dist_win;
%     for k = line
%         mu = mu + yy(int16(maximums(i))*100+k*100);
%     end
%     mu = mu / size(line, 2);
    sigma = 0;
    win = 5;
    if maximums(i) < win
        win = maximums(i);
    end
    if size(H, 2) < maximums(i) + win
        win = size(H,2) - maximums(i);
    end
    n=0;
    win
    dd = diff(yy,2)/(0.01^2);
    sigma = ( abs(1 / dd( maximums(i)*100 )) )^(1/3);%fminunc( @(x)(1/(sqrt(2*pi)*x^3) * ( maximums(i)^2 / x^2 - 1) * exp( - maximums(i)^2 / (2*x*x) ) - dd(maximums(i)*100)), 12 ); 
    %fsolve(@(x)f2drv(x, maximums(i), dd(maximums(i)*100) ), 1);
%     for k = maximums(i)-win : maximums(i)+win
%         sigma = sigma + (H(k) - mu )^2;
%         n= n + H(k);
%     end
%     n
%     sigma = sqrt( sigma / n );
%     size(line, 2)
    line = (maximums(i)-dist_win*2):0.01:(maximums(i)+dist_win*2);
    plot ( line, -yy(maximums(i)*100)*20*sqrt(2*pi)*sigma  /(sigma*sqrt(2*pi)) * exp( - ((line-mu).^2) / (2*sigma^2) ), '-','Color', 'k' );
    %line
    sigma
    
end

y = filter(ones(1,1)/1, 1, -1 .* H .* ones(1,size( H)) );
%yy = filter(ones(1,filter_window)/filter_window, 1, yy);
%yy = spline(1:size(H,2), y, 0:0.01:max(max(AB)) ); 
%yy
plot(  1:size(H,2),  4.*y,  'o', 'MarkerSize', 2, 'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'k');

plot( X, -yy*20 , 'Color', 'r', 'LineWidth',2);
H;
size(H);
%T_STAT_VALIDATE( Nt, events, levels, 7)
toc
%T_DRAW_PATTERNS(ss, events, Nt, -1);

%% From file
tic
levels = [ 1 0.05 3];
[events2, Nt] = T_LOAD_FILE('../real_data/grooming_hamsters/auratus7.txt'); %'../real_data/grooming_hamsters/auratus1.txt');
ss = mexPattern(events2, Nt, levels', 0, 2);
%T_STAT_VALIDATE( Nt, events2, levels, 7)
toc
T_DRAW_PATTERNS(ss, events2, Nt, -1 );



